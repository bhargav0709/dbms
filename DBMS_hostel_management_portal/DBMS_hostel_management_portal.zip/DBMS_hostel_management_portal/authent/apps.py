from django.apps import AppConfig


class AuthentConfig(AppConfig):
    name = 'authent'
